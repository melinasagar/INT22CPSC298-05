#include <iostream>
#include <array>
#include <vector>
using namespace std;

class Vectorize{
  vector<char>v; //vector
public:
  //char c[]; //array
  //int size; //size
  Vectorize(); //default
  Vectorize(char c[], int size);
  int get_size();
  void add(char a);
  void remove(char b);
  void remove(int c);
  char get(int y);
  void print();
  //~Vectorize();

};

//defining constructors
Vectorize::Vectorize(){
  cout<<"Default constructor used"<<endl;
}

Vectorize::Vectorize(char c[], int size){
  v.insert( v.begin(), c, c+size);
  cout<<"Constructor with parameter used"<<endl;
}


//functions
int Vectorize::get_size(){
  return v.size();
}
void Vectorize::add(char a){
  v.push_back(a);
}
void Vectorize::remove(char b){
  for (int i=0; i<v.size(); ++i){
    if(v[i]==b){
      v.erase(v.begin()+i);
    }
  }
}
void Vectorize::remove(int c){
  v.erase(v.begin()+c);
}
char Vectorize::get(int y){
  return v[y];
}

void Vectorize::print(){
  for (int i=0; i<v.size(); ++i){
    cout<<v.at(i)<<" ";
  }
  cout<<endl;
}

/*Vectorize::~Vectorize(){
  delete v;
}*/


int main(){
  char letters[2] = {'a','b'};
  Vectorize victor(letters,2);
  victor.add('c');
  victor.add('d');
  victor.remove('a');
  victor.remove(2);
  victor.print();
  cout << victor.get_size() << endl;
  cout << victor.get(0) << endl;
  return 0;
}
