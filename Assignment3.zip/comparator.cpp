#include <iostream>
using namespace std;

/*define a function str_compare, that takes two
strings as parameters and returns the first index at which the characters of the two
strings do not match. For example, if the input is aabbcc and aabccc, then the
function should return 3. In the main program repeatedly ask the user to enter 2
strings, space separated, and keep printing the output of the str_compare function
until the user provides “done done” as the input.*/

//prints 0 if theyre the same 
int str_compare(string a, string b){
  for (int i=0; i<a.length(); ++i){
    if(a[i]!=b[i]){
      return i;
    }
  }
}

int main(){
  while (true){
    string x;
    string y;
    cout<<"enter a word: ";
    getline(cin, x);
    if(x=="done done"){
      break;
    }
    else{
      cout<<"enter another word: ";
      getline(cin, y);
      if(y=="done done"){
        break;
      }
      cout<<str_compare(x,y)<<endl;
    }
  }
  return 0;
}
