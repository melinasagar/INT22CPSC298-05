#include <iostream>
using namespace std;

/*check_sign, that takes a single integer
as parameter and returns true if the parameter is positive, false if it is negative. In
the main program, ask the user for an integer and print the output of the function
using the input as argument. */

bool check_sign(int x){
  if(x>=0){
    return true;
  }
  else{
    return false;
  }
}
int main(){
  int a;
  cout<<"enter a number: ";
  cin>>a;
  cout<<check_sign(a)<<endl;
  return 0;
}
