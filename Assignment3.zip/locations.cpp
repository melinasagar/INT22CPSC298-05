#include <iostream>
using namespace std;

/*ask the user to enter an integer and store it in a
variable num. Next, create a pointer that points to the integer variable. Now, print
the address of num using the pointer. Also using the pointer, change the value of
num to 42. Finally, print the memory address of the pointer variable. */

int main(){
  int num;
  cout<<"enter an integer: ";
  cin>>num;
  int* pointer=&num;
  cout<<pointer<<endl;
  *pointer=42;
  cout<<&pointer<<endl;

  return 0;
}
