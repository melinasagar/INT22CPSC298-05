#include <iostream>
using namespace std;

/*define a function str_check, that takes a string and a
character as parameters and returns either the index of the character in the string
or -1 if the character is not found.  In the main program, ask the user for a string and
a character and print the index of the character in the string. If the character was not
found, print ‘character not found’*/

int str_check(string s, char c){
  int value=-1;
  for (int i=0; i<s.length(); ++i){
    if(s[i]==c){
      value=i;
    }
  }
  return value;

}
int main(){
  string user_string;
  cout<<"enter a word: ";
  getline(cin,user_string);
  char user_char;
  cout<<"enter a letter: ";
  cin>>user_char;
  int x=str_check(user_string, user_char);
  if(x==-1){
    cout<<"letter not found"<<endl;
  }
  else{
    cout<<x<<endl;
  }
  return 0;
}
