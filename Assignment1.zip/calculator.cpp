#include <iostream>
#include <sring>
#include <sstream>
#include <cmath>
#include <math.h>

//write a program to calculate x raised to the power of
//n (x^n). You will ask the user for x and n integer inputs and print the resulting value.
int main(){
  int result;
  int x;
  int n;
  cout<<"Enter an x value: ";
  cin>>x;
  cout<<"Enter an n value: ";
  cin>>n;
  result=pow(x,n);
  cout<<result;
  return 0;
}
