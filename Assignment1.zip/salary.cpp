#include <iostream>
#include <sring>
#include <sstream>

//A company provides a 5% bonus to employees if their years of service is more than 10 years.
//Ask the user for their salary and years of service and calculate and print their net
//bonus amount.
int main(){
  float service;
  float salary;
  cout<<"How many years have you worked? ";
  cin>>service;
  if (service>10){
    cout<<"what is your salary? ";
    float bonus=salary*0.05;
    cout<<bonus;
  }
  else{
    cout<<"Sorry no bonus";
  }
  return 0;

}
