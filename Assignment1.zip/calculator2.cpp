//In a file named calculator2.cpp, rewrite the above program. This time, however, you
//will check for the input data types and only print the answer if both inputs are
//integers. Otherwise print the message “incorrect inputs provided!”
#include <iostream>
#include <sring>
#include <sstream>
#include <cmath>
#include <math.h>

int math(){
  int result;
  int x;
  int n;
  cout<<"Enter an x value: ";
  cin>>x;
  cout<<"Enter an n value: ";
  cin>>n;
  if (x==int&&n==int){ //i know this is not right but i am not sure how to make the condition if a variable is a integer
    result=pow(x,n);
    cout<<result;
}
else{
  cout<<"incorrect inputs provided!";
}
  return 0;
}
