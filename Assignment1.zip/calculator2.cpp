//In a file named calculator2.cpp, rewrite the above program. This time, however, you
//will check for the input data types and only print the answer if both inputs are
//integers. Otherwise print the message “incorrect inputs provided!”
#include <iostream>
#include <sring>
#include <sstream>
#include <cmath>
#include <math.h>

int math(){
  
}
