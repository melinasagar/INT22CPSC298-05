#include <iostream>
#include <sring>
#include <sstream>

/*alculate the factorial of a number n
provided by the user using a for loop. You do not need to apply input checking for
this problem. */

int main(){
  int n;
  int factorial;
  cout<<"Enter a value for n: ";
  cin>>n;
  for (int i=1; i=n; ++i){
    factorial*=i;
    cout<<i;
  }
  return 0;
}
