#include <iostream>
#include <sring>
#include <sstream>

/*his time, calculate the
factorial using a while loop.  */

int main(){
  int factorial;
  int n;
  cout<<"enter an n value: ";
  cin>>n;
  while(true){
    if(n>=1){
      factorial*=n;
      --n;
    }
    else if{
      break;
    }
  }
  return 0;
}
